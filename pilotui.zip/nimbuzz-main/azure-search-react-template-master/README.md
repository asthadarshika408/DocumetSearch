# Azure Cognitive Search UI

This sample is a React template for [Azure Cognitive Search](https://docs.microsoft.com/en-us/azure/search/search-what-is-azure-search). It leverages the [Azure SDK for Javascript/Typescript](https://github.com/Azure/azure-sdk-for-js/tree/master/sdk/search/search-documents/) and [Azure Static Web Apps](https://aka.ms/swadocs) to make it easy to get up and running with a simple web application.

You can view the resulting web application here: [https://yellow-coast-0cbcefc03.azurestaticapps.net/](https://yellow-coast-0cbcefc03.azurestaticapps.net/)

![Screenshot of sample web app](./images/web-app.png)

You can easily deploy the sample onto Azure or run it locally by following the steps below.

## Running the application locally

To run the sample locally, follow the steps below.

### Prerequisites

- A GitHub account
- [Node.js and Git](https://nodejs.org/)
- [Visual Studio Code](https://code.visualstudio.com/?WT.mc_id=shopathome-github-jopapa) installed
- The [Azure Functions extension](https://marketplace.visualstudio.com/items?itemName=ms-azuretools.vscode-azurefunctions?WT.mc_id=shopathome-github-jopapa) installed
- The [Azure Functions Core Tools](https://docs.microsoft.com/azure/azure-functions/functions-run-local?WT.mc_id=shopathome-github-jopapa) installed

### Building the Azure Functions

With our search index and codebase in place, we’re ready to start building our application. The repo follows a pattern for Azure Static Web Apps that we’ll be using to build and deploy the application. The functions containing search logic can be found in the api folder.

One important consideration when building an application is keeping your API keys secure. It’s a best practice to design our application in a way that your API keys aren’t accessible from the client.

Azure Functions combined with the Azure SDKs are a simple and effective way to keep our keys out of users’ reach. These functions can also encapsulate any business logic you want to incorporate into the search experience such as security trimming or additional query proccesing.


![Use this template screenshot](./images/20201008-basic-arch.png)


### Setup

1. Clone (or Fork and Clone) this repository

1. Open file  `api/local.settings.json` and fill required data.

The `local.settings.json` file holds all of the keys that the application needs.

```json
{
  "IsEncrypted": false,
  "Values": {
    "AzureWebJobsStorage": "",
    "FUNCTIONS_WORKER_RUNTIME": "node",
    "SearchApiKey": "03097125077C18172260E41153975439",
    "SearchServiceName": "azs-playground",
    "SearchIndexName": "good-books",
    "SearchFacets": "authors*,language_code"
  }
}
```
### Forking the repo

To start off, select **Use this template** above. This will create your own copy of the code that you can deploy and edit as you please.

![Use this template screenshot](./images/use-template.png)


## Run the app locally

This project can be run anywhere, but VS Code is required for local debugging.

1. Open the application with VS Code.

### Running the front-end

1. Install front-end dependencies...

   ```bash
   npm install
   ```

1. Run the front-end project in the browser (automatically opens a browser window).

   ```bash
   npm start
   ```

### Running the API

1. From VS Code, press <kbd>F5</kbd>


## Deploying this sample

### Prerequisites

- A GitHub account
- An Azure subscription


### Creating the web app

Next, you need to create a Static Web App in the Azure portal. Click the button below to create one:

[![Deploy to Azure button](https://aka.ms/deploytoazurebutton)](https://portal.azure.com/?feature.customportal=false#create/Microsoft.StaticApp)

This will walk you through the process of creating the web app and connecting it to your GitHub repo.

After connecting to the repo, you'll be asked to include some build details. Set the Build Presets to `React` and then leave the other default values:

![Azure Static Web Apps Configuration Screenshot](./images/setup.png)

Once you create the static web app, it will automatically deploy the web app to a URL you can find within the portal.

![Azure Static Web Apps Configuration Screenshot](./images/static-web.png)

The last thing you need to do is select configuration and then edit the application settings to add the credentials from `local.settings.json`. It may take a few minutes for this blade to become available in the portal.

![Azure Static Web Apps Configuration Screenshot](./images/config.png)

Additional documentation can be found in the [docs folder](./docs).
